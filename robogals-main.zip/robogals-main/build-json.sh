#!/bin/bash

# Builds the .g.dart files for the Json Serializable widgets
flutter pub run build_runner build --delete-conflicting-outputs

