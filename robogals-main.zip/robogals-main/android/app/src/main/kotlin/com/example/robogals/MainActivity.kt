package io.gada.robogals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
